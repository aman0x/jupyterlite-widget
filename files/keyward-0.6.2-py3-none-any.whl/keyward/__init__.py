from .table_operations import table_operations, set_debug
from .api import api as keywardApi

# Create convenient alias
api = keywardApi

# Direct debug function to avoid import issues
def enable_debug():
    """Enable debug mode for troubleshooting"""
    set_debug(True)
    print("🔧 DEBUG MODE ENABLED - You'll see detailed logs of all operations")

# Add version
__version__ = "0.6.2"

# Make debug functions available at top level
__all__ = ['table_operations', 'keywardApi', 'api', 'enable_debug', 'set_debug', '__version__']
