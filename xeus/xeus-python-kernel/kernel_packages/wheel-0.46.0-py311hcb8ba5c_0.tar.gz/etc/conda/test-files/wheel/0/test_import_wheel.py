def test_import():
    import wheel