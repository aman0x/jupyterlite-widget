const _NULL = "0"
const _UNDEFINED = "1"
const _OBJECT = "2"
const _STR = "3"
const _INT = "4"
const _FLOAT = "5"
const _BOOL = "6"
const _FUNCTION = "7"

function _get_type_string(instance) {
    if (instance === null) {
        return _NULL
    } else if (instance === undefined) {
        return _UNDEFINED
    } else {
        const type = typeof instance;

        if (type === "object") {
            const constructor = instance.constructor;
            if (constructor !== undefined) {
                return constructor.name
            }
            return _OBJECT
        } else if (type === "string") {
            return _STR
        } else if (type === "number") {
            if (Number.isInteger(instance)) {
                return _INT
            } else {
                return _FLOAT
            }
        } else if (type === "boolean") {
            return _BOOL
        } else if (type === "function") {
            return _FUNCTION
        } else {
            console.log(instance, "is unhandled type")
            throw Error("internal error -- this should be unreachable")
        }
    }
}

Module['_get_type_string'] = _get_type_string


function _wrap_void_result() {
    return {
        has_err: false,
        has_ret: false
    }
}

function _wrap_return_value(raw_ret) {
    const is_none = (raw_ret === undefined || raw_ret === null);
    let wret = {
        ret: raw_ret,
        has_err: false,
        has_ret: !is_none,
        type_string: _get_type_string(raw_ret)
    }
    return wret;
}


function _wrap_jreturn_value(raw_ret) {
    if (raw_ret === undefined) {
        return {
            ret: "",
            has_err: false
        }
    } else {
        return {
            ret: JSON.stringify(raw_ret),
            has_err: false
        }
    }
}


function _wrap_catched_error(err) {
    return {
        err: err,
        has_err: true,
        has_ret: false
    }
}


function isPromise(p) {
  try{
    if (
        p !== null &&
        typeof p === 'object' &&
        typeof p.then === 'function' &&
        typeof p.catch === 'function'
    ) {
        return true;
    }
  } catch (e) {
  }
  return false;
}


Module['_apply_try_catch'] = function(obj, args, is_generated_proxy) {
    try {
        let res = obj(...args);
        if(isPromise(res)){
            res.then((value) => {
                for(let i=0; i<is_generated_proxy.length; ++i)
                {
                    if(is_generated_proxy[i]){
                        args[i].delete();
                    }
                }
            });
        }
        else{
            for(let i=0; i<is_generated_proxy.length; ++i)
            {
                if(is_generated_proxy[i]){
                    args[i].delete();
                }
            }
        }
        return _wrap_return_value(res);
    } catch (e) {
        return _wrap_catched_error(e);
    }
}



Module['_gapply_try_catch'] = function(obj, args, is_generated_proxy, jin, jout) {
    try {
        if (jin) {
            args = JSON.parse(args)
        }
        if (jout) {
            return _wrap_jreturn_value(obj(...args));
        } else {
            return _wrap_return_value(obj(...args));
        }
    } catch (e) {
        return _wrap_catched_error(e);
    }
}


Module['_japply_try_catch'] = function(obj, jargs) {
    try {
        args = JSON.parse(jargs)
        return _wrap_return_value(obj(...args));
    } catch (e) {
        return _wrap_catched_error(e);
    }
}


Module['_getattr_try_catch'] = function(obj, property_name) {
    try {
        let ret = obj[property_name]
        if (typeof ret === "function") {
            return _wrap_return_value(ret.bind(obj))
        } else {
            return _wrap_return_value(ret)
        }
    } catch (e) {
        return _wrap_catched_error(e)
    }
}
Module['_setattr_try_catch'] = function(obj, property_name, value) {
    try {

        obj[property_name] = value
        return _wrap_void_result()
    } catch (e) {
        return _wrap_catched_error(e)
    }
}


Module['_set_promise_then_catch'] = function(promise, py_object_then, py_object_catch) {

    let already_called = false;

    var callable_then = function(v) {

        py_object_then.__usafe_void_val__(v);

        // delete
        py_object_then.delete()
        py_object_catch.delete()
    }
    var callable_catch = function(err) {

        str_err = JSON.stringify(err, Object.getOwnPropertyNames(err))
        py_object_catch.__usafe_void_val__(str_err);

        // delete
        py_object_then.delete()
        py_object_catch.delete()
    }
    promise.then(callable_then).catch(callable_catch)
}

Module['_future_to_promise'] = function(py_future){
    let p  = new Promise(function(resolve, reject) {
        Module._add_resolve_done_callback.py_call(py_future, resolve, reject)
    });

    p.then(function(value) {
        py_future.delete()
      }, function(reason) {
        py_future.delete()
    });
    return p;
}

Module['_create_once_callable'] = function(py_object) {

    let already_called = false;

    var once_callable = function(...args) {
        if (already_called) {
            throw new Error("once_callable can only be called once");
        }
        already_called = true;

        // make the call
        ret = py_object.py_call(...args);

        // delete
        py_object.delete()

        return ret;
    }
    return once_callable
}

Module['_create_once_callable_unsave_void_void'] = function(py_object) {

    let already_called = false;

    var once_callable = function() {
        if (already_called) {
            throw new Error("once_callable can only be called once");
        }
        already_called = true;

        // make the call
        py_object.__usafe_void_void__();

        // delete
        py_object.delete()
    }
    return once_callable
}

Module['_is_null'] = function(value) {
    return value === null;
}

Module['_is_undefined'] = function(value) {
    return value === undefined;
}

Module['_is_undefined_or_null'] = function(value) {
    return value === undefined || value === null;
}

Module["__len__"] = function(instance) {
    return instance.length || instance.size
}

Module["__contains__"] = function(instance, query) {
    let _has = false;
    let _includes = false;
    try {
        _has = instance.has(query);
    } catch (e) {}
    try {
        _has = instance.includes(query);
    } catch (e) {}
    return _has || _includes;
}

Module['_dir'] = function dir(x) {
    let result = [];
    do {
        result.push(...Object.getOwnPropertyNames(x));
    } while ((x = Object.getPrototypeOf(x)));
    return result;
}

Module['_iter'] = function dir(x) {
    return x[Symbol.iterator]()
}

Module['_async_import_javascript'] = async function(import_str){
    return import(import_str);
}

Module["__eq__"] = function(a, b) {
    return a === b;
}

Module['_new'] = function(cls, ...args) {
    return new cls(...args);
}

Module['_instanceof'] = function(instance, cls) {
    return (instance instanceof cls);
}

Module["_typeof"] = function(x) {
    return typeof x;
}

Module["_delete"] = function(x, key) {
    delete x[key];
}


Module['_IS_NODE'] = (typeof process === "object" && typeof require === "function")

Module['_IS_BROWSER_WORKER_THREAD'] = (typeof importScripts === "function")

Module['_IS_BROWSER_MAIN_THREAD'] = (typeof window === "object")

Module['_wait_run_dependencies'] = function() {
    const promise = new Promise((r) => {
        Module.monitorRunDependencies = (n) => {
            if (n === 0) {
                r();
            }
        };
    });
    Module.addRunDependency("dummy");
    Module.removeRunDependency("dummy");
    return promise;
}

Module._is_initialized = false



Module['init_phase_1'] = async function(prefix, python_version, verbose) {

    if(verbose){console.log("in init phase 1");}    
    let version_str = `${python_version[0]}.${python_version[1]}`;

    // list of python objects we need to delete when cleaning up
    let py_objects = []
    Module._py_objects = py_objects

    // return empty promise when already initialized
    if(Module["_is_initialized"])
    {
        return Promise.resolve();
    }
    var p = await Module['_wait_run_dependencies']();

    if(prefix == "/"){
        Module.setenv("PYTHONHOME", `/`);
        Module.setenv("PYTHONPATH", `/lib/python${version_str}/site-packages:/usr/lib/python${version_str}`);

        var side_path = `/lib/python${version_str}/site-packages`;
    }
    else{
        Module.setenv("PYTHONHOME", prefix);
        Module.setenv("PYTHONPATH", `${prefix}/lib/python${version_str}/site-packages:/usr/lib/python${version_str}`);
        var side_path = `${prefix}/lib/python${version_str}/site-packages`;
    }


    Module.create_directories(side_path);
    

    Module["_interpreter"] = new Module["_Interpreter"]()
    var default_scope = Module["main_scope"]()
    Module["default_scope"] = default_scope;

    Module['_py_objects'].push(Module["default_scope"]);
    Module['_py_objects'].push(Module["_interpreter"]);



    Module['exec'] = function(code, globals=default_scope, locals=default_scope) {
        let ret = Module._exec(code, globals, locals)
        if (ret.has_err) {
            throw ret
        }
    };



    Module['eval'] = function(code, globals=default_scope, locals=default_scope) {
        let ret = Module._eval(code, globals, locals)
        if (ret.has_err) {
            throw ret
        } else {
            return ret['ret']
        }
    };

    Module['eval_file'] = function(file, globals=default_scope, locals=default_scope) {
        let ret = Module._eval_file(file, globals, locals)
        if (ret.has_err) {
            throw ret
        }
    };

    Module['pyobject'].prototype._getattr = function(attr_name) {
        let ret = this._raw_getattr(attr_name)
        if (ret.has_err) {
            throw ret
        } else {
            return ret['ret']
        }
    };

    Module['pyobject'].prototype.py_call = function(...args) {
        return this.py_apply(args)
    };

    Module['pyobject'].prototype.py_apply = function(args, kwargs) {

        if (args === undefined) {
            var args = []
            var args_types = []
        }
        else
        {
            var args_types = args.map(Module['_get_type_string'])
        }

        if (kwargs === undefined) {
            var kwargs = {}
            var kwargs_keys = []
            var kwargs_values = []
            var kwarg_values_types = []
        }
        else
        {
            var kwargs_keys = Object.keys(kwargs)
            var kwargs_values = Object.values(kwargs)
            var kwarg_values_types = kwargs_values.map(Module['_get_type_string'])
        }

        let ret = this._raw_apply(args, args_types, args.length,
            kwargs_keys, kwargs_values, kwarg_values_types, kwargs_keys.length
        )
        if (ret.has_err) {
            throw ret
        } else {
            return ret['ret']
        }
    };

    // [Symbol.toPrimitive](hint) for pyobject
    Module['pyobject'].prototype[Symbol.toPrimitive] = function(hint) {
        return this.__toPrimitive();
    };




    Module['pyobject'].prototype.get = function(...keys) {


        let types = keys.map(Module['_get_type_string'])
        let ret = this._raw_getitem(keys, types, keys.length)
        if (ret.has_err) {
            throw ret
        } else {
            return ret['ret']
        }
    };
    if(verbose){console.log("in init phase 2 done");}    
}

Module['init_phase_2'] =  function(prefix, python_version, verbose) {
    let default_scope = Module["default_scope"];

    // make the python pyjs module easy available
    if(verbose){console.log("in init phase 2");}

    Module.exec(`
import traceback
try:
    import pyjs
except Exception as e:
    print("ERROR",e)
    traceback.print_exc()
    raise e
    `)

    if(verbose){console.log("assign pyobjects I");}
    Module.py_pyjs = Module.eval("pyjs")
    Module._py_objects.push(Module.py_pyjs);


    // execute a script and return the value of the last expression
    if(verbose){console.log("assign pyobjects II");}
    Module._py_exec_eval = Module.eval("pyjs.exec_eval")
    Module._py_objects.push(Module._py_exec_eval)
    Module.exec_eval = function(script, globals=default_scope, locals=default_scope){
        return Module._py_exec_eval.py_call(script, globals, locals)
    }

    // ansync execute a script and return the value of the last expression
    if(verbose){console.log("assign pyobjects III");}
    Module._py_async_exec_eval = Module.eval("pyjs.async_exec_eval")
    Module._py_objects.push(Module._py_async_exec_eval)
    Module.async_exec_eval = async function(script, globals=default_scope, locals=default_scope){
        return await Module._py_async_exec_eval.py_call(script, globals, locals)
    }
    if(verbose){console.log("assign pyobjects IV");}
    Module._add_resolve_done_callback  = Module.exec_eval(`
import asyncio
def _add_resolve_done_callback(future, resolve, reject):
    ensured_future = asyncio.ensure_future(future)
    def done(f):
        try:
            resolve(f.result())
        except Exception as err:
            reject(repr(err))

    ensured_future.add_done_callback(done)
_add_resolve_done_callback
    `)
    Module._py_objects.push(Module._add_resolve_done_callback);



    Module._py_to_js = Module.eval("pyjs.to_js")
    Module._py_objects.push(Module._py_to_js);

    Module["to_js"] = function(obj){
        return Module._py_to_js.py_call(obj)
    }

    Module._is_initialized = true;

    // Mock some system libraries
    Module.exec(`
import sys
import types
import time

sys.modules["fcntl"] = types.ModuleType("fcntl")
sys.modules["pexpect"] = types.ModuleType("pexpect")
sys.modules["resource"] = types.ModuleType("resource")

def _mock_time_sleep():
    def sleep(seconds):
        """Delay execution for a given number of seconds.  The argument may be
        a floating point number for subsecond precision.
        """
        start = now = time.time()
        while now - start < seconds:
            now = time.time()

    time.sleep = sleep
_mock_time_sleep()
del _mock_time_sleep

def _mock_termios():
    termios_mock = types.ModuleType("termios")
    termios_mock.TCSAFLUSH = 2
    sys.modules["termios"] = termios_mock
_mock_termios()
del _mock_termios

def _mock_webbrowser():
    def open(url, new=0, autoraise=True):
        pass
    def open_new(url):
        return open(url, 1)
    def open_new_tab(url):
        return open(url, 2)

    webbrowser_mock = types.ModuleType("webbrowser")
    webbrowser_mock.open = open
    webbrowser_mock.open_new = open_new
    webbrowser_mock.open_new_tab = open_new_tab

    sys.modules["webbrowser"] = webbrowser_mock
_mock_webbrowser()
del _mock_webbrowser
`);
    if(verbose){console.log("init phase 2 done");}
}


Module['cleanup'] = function()
{
    if(Module["_is_initialized"])
    {
        Module['_py_objects'].forEach(pyobject => pyobject.delete())
        Module["_is_initialized"] = false
    }
}

Module['make_proxy'] = function(py_object) {
    const handler = {
        get(target, property, receiver) {
            var ret = target[property]
            if (ret !== undefined) {
                return ret
            }
            return target._getattr(property);
        }
    };

    return new Proxy(py_object, handler);
}

const memoize = (fn) => {
    let cache = {};
    return (...args) => {
        let n = args[0];
        if (n in cache) {
            return cache[n];
        } else {
            let result = fn(n);
            cache[n] = result;
            return result;
        }
    };
};


function createLock() {
    let _lock = Promise.resolve();

    async function acquireLock() {
        const old_lock = _lock;
        let releaseLock = () => { };
        _lock = new Promise((resolve) => (releaseLock = resolve));
        await old_lock;
        return releaseLock;
    }
    return acquireLock;
}

function isInSharedLibraryPath(prefix, libPath){
    if (libPath.startsWith("/")){
        const dirname = libPath.substring(0, libPath.lastIndexOf("/"));
        if(prefix == "/"){
            return (dirname == `/lib`);
        }
        else{
          return (dirname == `${prefix}/lib`);
        }
    }
    else{
        return false;
    }
}


async function loadDynlibsFromPackage(
    prefix,
    python_version,
    pkg_file_name,
    pkg_is_shared_library,
    dynlibPaths,
  ) {

    // for(const path of dynlibPaths){
    //     console.log(path);
    // }

    // assume that shared libraries of a package are located in <package-name>.libs directory,
    // following the convention of auditwheel.
    if(prefix == "/"){
        var sitepackages = `/lib/python${python_version[0]}.${python_version[1]}/site-packages`
    }
    else{
        var sitepackages = `${prefix}/lib/python${python_version[0]}.${python_version[1]}/site-packages`
    }
    const auditWheelLibDir = `${sitepackages}/${
        pkg_file_name.split("-")[0]
    }.libs`;
  
    // This prevents from reading large libraries multiple times.
    const readFileMemoized = memoize(Module.FS.readFile);
  
    const forceGlobal = !!pkg_is_shared_library;
    


    let dynlibs = [];
  
    if (forceGlobal) {
      dynlibs = dynlibPaths.map((path) => {
        return {
          path: path,
          global: true,
        };
      });
    } else {
      const globalLibs = calculateGlobalLibs(
        dynlibPaths,
        readFileMemoized,
      );

      dynlibs = dynlibPaths.map((path) => {
        const global = globalLibs.has(Module.PATH.basename(path));
        return {
          path: path,
          global: global || !! pkg_is_shared_library || isInSharedLibraryPath(prefix, path) || path.startsWith(auditWheelLibDir),
        };
      });
    }
  
    dynlibs.sort((lib1, lib2) => Number(lib2.global) - Number(lib1.global));

    for (const { path, global } of dynlibs) {
      await loadDynlib(prefix, path, global, [auditWheelLibDir], readFileMemoized);
    }
  }

function createDynlibFS(
    prefix,
    lib,
    searchDirs,
    readFileFunc
) {
    const dirname = lib.substring(0, lib.lastIndexOf("/"));

    let _searchDirs = searchDirs || [];

    if(prefix == "/"){
        _searchDirs = _searchDirs.concat([dirname], [`/lib`]);
    }
    else{
        _searchDirs = _searchDirs.concat([dirname], [`${prefix}/lib`]);
    }


    const resolvePath = (path) => {
        //console.log("resolvePath", path);
        
        if (Module.PATH.basename(path) !== Module.PATH.basename(lib)) {
            //console.debug(`Searching a library from ${path}, required by ${lib}`);
        }

        for (const dir of _searchDirs) {
            const fullPath = Module.PATH.join2(dir, path);
            //console.log("SERARCHING", fullPath);
            if (Module.FS.findObject(fullPath) !== null) {
                //console.log("FOUND", fullPath);   
                return fullPath;
            }
        }
        return path;
    };

    let readFile = (path) =>
        Module.FS.readFile(resolvePath(path));

    if (readFileFunc !== undefined) {
        readFile = (path) => readFileFunc(resolvePath(path));
    }

    const fs = {
        findObject: (path, dontResolveLastLink) => {
            let obj = Module.FS.findObject(resolvePath(path), dontResolveLastLink);

            if (obj === null) {
                console.debug(`Failed to find a library: ${resolvePath(path)}`);
            }

            return obj;
        },
        readFile: readFile,
    };

    return fs;
}


function calculateGlobalLibs(
    libs,
    readFileFunc
) {
    let readFile = Module.FS.readFile;
    if (readFileFunc !== undefined) {
        readFile = readFileFunc;
    }

    const globalLibs = new Set();

    libs.forEach((lib) => {
        const binary = readFile(lib);
        const needed = Module.getDylinkMetadata(binary).neededDynlibs;
        needed.forEach((lib) => {
            globalLibs.add(lib);
        });
    });

    return globalLibs;
}


// Emscripten has a lock in the corresponding code in library_browser.js. I
// don't know why we need it, but quite possibly bad stuff will happen without
// it.
const acquireDynlibLock = createLock();

async function loadDynlib(prefix, lib, global, searchDirs, readFileFunc) {
    if (searchDirs === undefined) {
        searchDirs = [];
    }
    const releaseDynlibLock = await acquireDynlibLock();

    try {
        const fs = createDynlibFS(prefix, lib, searchDirs, readFileFunc);

        const libName = Module.PATH.basename(lib);
        
        // contains cpython-3 and with wasm32-emscripten
        const is_cython_lib = libName.includes("cpython-3") && libName.includes("wasm32-emscripten");

        // load cython library from full path
        const load_name = is_cython_lib ? lib : libName;

        await Module.loadDynamicLibrary(load_name, {
            loadAsync: true,
            nodelete: true,
            allowUndefined: true,
            global: global && !is_cython_lib,
            fs: fs
        })
        
        const dsoOnlyLibName = Module.LDSO.loadedLibsByName[libName];
        const dsoFullLib = Module.LDSO.loadedLibsByName[lib];

        if(!dsoOnlyLibName && !dsoFullLib){
            console.execption(`Failed to load ${libName} from ${lib} LDSO not found`);
        }

        if(!is_cython_lib){
            if (!dsoOnlyLibName) {
                Module.LDSO.loadedLibsByName[libName] = dsoFullLib
            }
            
            if(!dsoFullLib){
                Module.LDSO.loadedLibsByName[lib] = dsoOnlyLibName;
            }
        }
    } finally {
        releaseDynlibLock();
    }
}

Module["_loadDynlibsFromPackage"] = loadDynlibsFromPackage;







async function fetchByteArray(url){
    let response = await fetch(url)
    if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
    }
    let arrayBuffer = await response.arrayBuffer()
    let byte_array = new Uint8Array(arrayBuffer)
    return byte_array
}

Module["_fetch_byte_array"] = fetchByteArray;


async function fetchJson(url){
    let response = await fetch(url)
    if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
    }
    let json = await response.json()
    return json
}



Module["_parallel_fetch_array_buffer"] = async function (urls){
    let promises = urls.map(url => fetch(url).then(response => response.arrayBuffer()));
    return await Promise.all(promises);
}

Module["_parallel_fetch_arraybuffers_with_progress_bar"] = async function (urls, done_callback, progress_callback){
    if(done_callback === undefined || done_callback === null){
        done_callback = async function(
            index, byte_array
        ){};
    }

    if(progress_callback===undefined || progress_callback===null)
    {   

        let f = async function(index){
            let res = await fetch(urls[index]);
            if (!res.ok) {
                throw new Error(`HTTP error! when fetching ${urls[index]} status: ${res.status}`);
            }
            const arrayBuffer = await res.arrayBuffer();
            const byteArray = new Uint8Array(arrayBuffer);
            await done_callback(index, byteArray);
            return byteArray;
        }
        let futures = []
        for(let i=0;i<urls.length;i++){
            futures.push(f(i))
        }
        return await Promise.all(futures);
    }
    
    async function fetch_arraybuffer_with_progress_bar(url,index, report_total_length,report_progress, report_finished){
        let response = await fetch(url);
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }        
        const reader = response.body.getReader();

        // Step 2: get total length
        const contentLength = +response.headers.get('Content-Length');
        report_total_length(index, contentLength);
        // Step 3: read the data
        let receivedLength = 0; // received that many bytes at the moment
        let chunks = []; // array of received binary chunks (comprises the body)
        while(true) {
            const {done, value} = await reader.read();
            if (done) {
                report_finished(index);
                break;
            }
            chunks.push(value);
            receivedLength += value.length;
            report_progress(index, receivedLength);
        }
        // Step 4: concatenate chunks into single Uint8Array
        let chunksAll = new Uint8Array(receivedLength); // (4.1)
        let position = 0;
        for(let chunk of chunks) {
            chunksAll.set(chunk, position); // (4.2)
            position += chunk.length;
        }
        await done_callback(index, chunksAll);
        return chunksAll
    }
    let n_urls = urls.length;
    let receivedArr = Array(n_urls).fill(0);
    let totalArr = Array(n_urls).fill(0);
    let finishedArr = Array(n_urls).fill(0);
    function on_progress(){
        let total = totalArr.reduce((partialSum, a) => partialSum + a, 0);
        let recived = receivedArr.reduce((partialSum, a) => partialSum + a, 0);
        let n_finished = finishedArr.reduce((partialSum, a) => partialSum + a, 0);
        
        if(progress_callback !== undefined){
            progress_callback(recived,total,n_finished, n_urls);
        }
    }
    
    function report_finished(index){
        finishedArr[index] = 1;
        on_progress();
    }
         
    function report_total_length(index, total){
        totalArr[index] = total;
        on_progress();
    }
    function report_progress(index, p){
        receivedArr[index] = p;
        on_progress();
    }
    
    let futures = urls.map((url, index) => {
        return fetch_arraybuffer_with_progress_bar(url,index, report_total_length,report_progress, report_finished)
    })
    return await Promise.all(futures);
}
Module["mkdirs"] = function (dirname) {
    // get all partent directories
    let parent_dirs = []
    let parent_dir = dirname
    while (parent_dir != "") {
        parent_dirs.push(parent_dir)
        parent_dir = parent_dir.split("/").slice(0, -1).join("/")
    }
    console.log(parent_dirs)
    // make directories
    parent_dirs = parent_dirs.reverse()
    for (let parent_dir of parent_dirs) {
        if (!Module.FS.isDir(parent_dir)) {
            Module.FS.mkdir(parent_dir)
        }
    }
}



Module["_untar_from_python"] = function(tarball_path, target_dir = "") {
    Module.exec(`
def _py_untar(tarball_path, target_dir):
    import tarfile
    import json
    from pathlib import Path
    import tempfile
    import shutil
    import os
    import sys


    def check_wasm_magic_number(file_path: Path) -> bool:
        WASM_BINARY_MAGIC = b"\\0asm"
        with file_path.open(mode="rb") as file:
            return file.read(4) == WASM_BINARY_MAGIC

        
    target_dir = target_dir
    if target_dir == "":
        target_dir = sys.prefix
    try:
        with tarfile.open(tarball_path) as tar:
            files = tar.getmembers()
            shared_libs = []
            for file in files:
                if file.name.endswith(".so") or ".so." in file.name:
                    if target_dir == "/":
                        shared_libs.append(f"/{file.name}")
                    else:
                        shared_libs.append(f"{target_dir}/{file.name}")

            tar.extractall(target_dir)
            actual_shared_libs = []
            for file in shared_libs:
                if not check_wasm_magic_number(Path(file)):
                    print(f" {file} is not a wasm file")
                else:
                    actual_shared_libs.append(file)
            s = json.dumps(actual_shared_libs)
    except Exception as e:
        print("ERROR",e)
        raise e
    return s
`)
    let shared_libs = Module.eval(`_py_untar("${tarball_path}", "${target_dir}")`)

    return JSON.parse(shared_libs)
}


Module["_unzip_from_python"] = function(tarball_path, target_dir) {
    Module.exec(`
def _py_unzip(tarball_path, target_dir):
    import json
    from pathlib import Path
    import zipfile
    
    target = Path(target_dir)
    target.mkdir(parents=True, exist_ok=True)
    pkg_file = {"name": "", "path": ""}
    with zipfile.ZipFile(tarball_path, mode="r") as archive:
        
        for filename in archive.namelist():
            if filename.startswith("pkg-"):
                pkg_file["name"] = filename
                pkg_file["path"] = str(target / filename)
                archive.extract(filename, target_dir)    
                break
    return json.dumps(pkg_file)

`)
    let extracted_file = Module.eval(`_py_unzip("${tarball_path}", "${target_dir}")`)

    return JSON.parse(extracted_file)
}

Module["_install_conda_file_from_python"] = function(tarball_path, target_dir) {
    Module.exec(`
def _py_unbz2(tarball_path, target_dir):
    import json
    from pathlib import Path
    import tarfile
    import shutil
    import os
    import sys
    
    target = Path(target_dir)
    prefix = Path(sys.prefix)
    try:
        with tarfile.open(tarball_path) as tar:
            tar.extractall(target_dir)

        src = target / "site-packages"
        dest = prefix / "lib/python3.11/site-packages"
        shutil.copytree(src, dest, dirs_exist_ok=True)
        for folder in ["etc", "share"]:
            src = target / folder
            dest = prefix / folder
            if src.exists():
                shutil.copytree(src, dest, dirs_exist_ok=True)
        shutil.rmtree(target)
    except Exception as e:
        print("ERROR",e)
        raise e
    
    return json.dumps([])

`)
    let extracted_file = Module.eval(`_py_unbz2("${tarball_path}", "${target_dir}")`)

    return JSON.parse(extracted_file)
}





Module["bootstrap_from_empack_packed_environment"] = async function
    (   
        packages_json_url,
        package_tarballs_root_url,
        verbose = true,
        skip_loading_shared_libs = false
    ) 
{
    try{
    
        function splitPackages(packages) {
            // find package with name "python" and remove it from the list
            let python_package = undefined
            for (let i = 0; i < packages.length; i++) {
                if (packages[i].name == "python") {
                    python_package = packages[i]
                    packages.splice(i, 1)
                    break
                }
            }
            if (python_package == undefined) {
                throw new Error("no python package found in package.json")
            }
            return { python_package, packages }
        }
        

        
        async function fetchAndUntar
            (
                package_tarballs_root_url,
                python_is_ready_promise,
                pkg,
                verbose
            ) {
              const package_url =
                pkg?.url ?? `${package_tarballs_root_url}/${pkg.filename}`;
              if (verbose) {
                console.log(`!!fetching pkg ${pkg.name} from ${package_url}`);
              }
              let byte_array = await fetchByteArray(package_url);
              const tarball_path = `/package_tarballs/${pkg.filename}`;
              Module.FS.writeFile(tarball_path, byte_array);
              if (verbose) {
                console.log(
                  `!!extract ${tarball_path} (${byte_array.length} bytes)`
                );
              }

              if (verbose) {
                console.log("await python_is_ready_promise");
              }
              await python_is_ready_promise;

              if (package_url.toLowerCase().endsWith(".conda")) {
                // Conda v2 packages
                if (verbose) {
                  console.log(
                    `!!extract conda package ${package_url} (${byte_array.length} bytes)`
                  );
                }
                const dest = `/conda_packages/${pkg.name}`;
                const pkg_file = Module["_unzip_from_python"](
                  tarball_path,
                  dest
                );
                return Module._install_conda_file(pkg_file.path, dest, prefix);
              } else if (package_url.toLowerCase().endsWith(".tar.bz2")) {
                // Conda v1 packages
                if (verbose) {
                  console.log(
                    `!!extract conda package ${package_url} (${byte_array.length} bytes)`
                  );
                }
                const dest = `/conda_packages/${pkg.name}`;
                return Module["_install_conda_file_from_python"](
                  tarball_path,
                  dest
                );
              } else {
                // Pre-relocated packages
                return Module["_untar_from_python"](tarball_path);
              }
            }

        
        async function bootstrap_python(prefix, package_tarballs_root_url, python_package, verbose) {
            // fetch python package
            const python_package_url = python_package?.url ?? `${package_tarballs_root_url}/${python_package.filename}`;
        
            if (verbose) {
                console.log(`fetching python package from ${python_package_url}`)
            }
            let byte_array = await fetchByteArray(python_package_url)
        
            const python_tarball_path = `/package_tarballs/${python_package.filename}`;
            if(verbose){
                console.log(`extract ${python_tarball_path} (${byte_array.length} bytes)`)
            }
            Module.FS.writeFile(python_tarball_path, byte_array);
            if(verbose){console.log("untar_from_python");}
            Module._untar(python_tarball_path, prefix);
            
            
        
        
        
            // split version string into major and minor and patch version
            let version = python_package.version.split(".").map(x => parseInt(x));
        
        
            if(verbose){console.log("start init_phase_1");}
            await Module.init_phase_1(prefix, version, verbose);
        }
        
        
        
        if(verbose){
            console.log("fetching packages.json from", packages_json_url)
        }

        // fetch json with list of all packages
        let empack_env_meta = await fetchJson(packages_json_url);
        let all_packages = empack_env_meta.packages;
        let prefix = empack_env_meta.prefix;

        if(verbose){
            console.log("makeDirs");
        }
        Module.create_directories("/package_tarballs");
        
        // enusre there is python and split it from the rest
        if(verbose){console.log("splitPackages");}
        let splitted = splitPackages(all_packages);
        let packages = splitted.packages;
        let python_package = splitted.python_package;
        let python_version = python_package.version.split(".").map(x => parseInt(x));

        // fetch init python itself
        console.log("--bootstrap_python");
        if(verbose){
            console.log("bootstrap_python");
        }
        let python_is_ready_promise = bootstrap_python(prefix, package_tarballs_root_url, python_package, verbose);

        // create array with size 
        if(verbose){
            console.log("fetchAndUntarAll");
        }
        let shared_libs = await Promise.all(packages.map(pkg => fetchAndUntar(package_tarballs_root_url, python_is_ready_promise, pkg, verbose)));

        if(verbose){
            console.log("init_phase_2");
        }       
        Module.init_phase_2(prefix, python_version, verbose);

        if(verbose){
            console.log("init shared");
        }     
        if(!skip_loading_shared_libs){
            // instantiate all packages
            for (let i = 0; i < packages.length; i++) {

                // if we have any shared libraries, load them
                if (shared_libs[i].length > 0) {

                    for (let j = 0; j < shared_libs[i].length; j++) {
                        let sl = shared_libs[i][j];
                    }
                    await Module._loadDynlibsFromPackage(
                        prefix,
                        python_version,
                        packages[i].name,
                        false,
                        shared_libs[i]
                    )
                }
            }
        }
        if(verbose){
            console.log("done bootstrapping");}         
    }
    catch(e){
        console.log("error in bootstrapping process")
        console.error(e);
    }
}

